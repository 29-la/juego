package co.edu.uniquindio.poo;
import java.util.LinkedList;
import java.util.Optional;

public class Jugador{
    private String nombre;
    private LinkedList<Personaje> listaPersonajes;

    public Jugador(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
//validar personaje no este repetido
    public void agregarPersonaje(Personaje personaje){
        //optional valida personaje igual nombre existe
        Optional<Personaje> personajeExiste = listaPersonajes.stream().
        filter(p-> p.getNombre().equals(personaje.getNombre())).findAny();
        //si el personaje existe entonces se lanza una excepcion, si no, 
        //se agregua el personaje a la lista de personajes
        if(personajeExiste.isPresent()){
            throw new IllegalArgumentException("El personaje ya existe en la lista.");
        }else{
            listaPersonajes.add(personaje);
        }
    }

    
}