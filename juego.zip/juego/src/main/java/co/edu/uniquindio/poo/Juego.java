package co.edu.uniquindio.poo;
import java.util.LinkedList;
import java.util.Optional;


public class Juego {

private LinkedList<Jugador> jugadores;
private String nombre;


public Juego(LinkedList<Jugador> jugadores, String nombre) {
    this.jugadores = jugadores;
    this.nombre = nombre;
}


public LinkedList<Jugador> getJugadores() {
    return jugadores;
}


public void setPersonajes(LinkedList<Jugador> jugadores) {
    this.jugadores = jugadores;
}


public String getNombre() {
    return nombre;
}


public void setNombre(String nombre) {
    this.nombre = nombre;
}


    public void agregarJugador(Jugador jugador){
        
        Optional<Jugador> personajeExiste = jugadores.stream().filter(j-> j.
        getNombre().equals(jugador.getNombre())).findAny();
        
        if(personajeExiste.isPresent()){
            throw new IllegalArgumentException("El Jugador ya existe en la lista.");
        }else{
            jugadores.add(jugador);
        }
    }
}
