package co.edu.uniquindio.poo;

public abstract class Personaje  {
    private String nombre;
    private String apodo;
    private String dineroInicial;
    public Personaje(String nombre, String apodo, String dineroInicial) {
        this.nombre = nombre;
        this.apodo = apodo;
        this.dineroInicial = dineroInicial;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApodo() {
        return apodo;
    }
    public void setApodo(String apodo) {
        this.apodo = apodo;
    }
    public String getDineroInicial() {
        return dineroInicial;
    }
    public void setDineroInicial(String dineroInicial) {
        this.dineroInicial = dineroInicial;
    }

    public abstract void habilidad1();
    public abstract void habilidad2();
    public abstract void habilidad3();
    
}
